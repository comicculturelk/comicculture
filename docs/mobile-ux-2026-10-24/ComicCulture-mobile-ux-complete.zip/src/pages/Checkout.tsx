import { cloneElement, isValidElement, useId, useRef, useState } from 'react';
import type { ChangeEvent, FormEvent, ReactElement, ReactNode } from 'react';
import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Truck,
  CheckCircle2,
  Tag,
  Loader2,
  ShoppingBag,
  Wallet,
  Landmark,
  Info,
  Upload,
  AlertCircle,
} from 'lucide-react';
import { useCart } from '../hooks/useCart';
import { useProducts } from '../hooks/useProducts';
import { CHECKOUT_ERROR_MESSAGE, createOrder } from '../data/orders';
import { formatPrice, getPreorderMessage } from '../data/products';
import { uploadFile } from '../lib/storage';
import { STORE_CONFIG } from '../config/store';
import { supabase } from '../lib/supabase';

const RECEIPT_MAX_BYTES = 5 * 1024 * 1024; // 5MB

const DISTRICTS = [
  'Ampara', 'Anuradhapura', 'Badulla', 'Batticaloa', 'Colombo', 'Galle',
  'Gampaha', 'Hambantota', 'Jaffna', 'Kalutara', 'Kandy', 'Kegalle',
  'Kilinochchi', 'Kurunegala', 'Mannar', 'Matale', 'Matara', 'Moneragala',
  'Mullaitivu', 'Nuwara Eliya', 'Polonnaruwa', 'Puttalam', 'Ratnapura',
  'Trincomalee', 'Vavuniya',
];

interface CheckoutForm {
  fullName: string;
  phone: string;
  mobilePhone: string;
  email: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  district: string;
  postalCode: string;
}

const EMPTY_FORM: CheckoutForm = {
  fullName: '',
  phone: '',
  mobilePhone: '',
  email: '',
  addressLine1: '',
  addressLine2: '',
  city: '',
  district: '',
  postalCode: '',
};

type FormErrors = Partial<Record<keyof CheckoutForm, string>>;

type PaymentMethod = 'COD' | 'BANK_TRANSFER';

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_REGEX = /^[0-9+\-\s]{9,15}$/;

export default function Checkout() {
  const navigate = useNavigate();
  const checkoutFormRef = useRef<HTMLFormElement>(null);
  const { items, totalItems, totalPrice, clearCart } = useCart();
  const { products } = useProducts();
  const [form, setForm] = useState<CheckoutForm>(EMPTY_FORM);
  const [errors, setErrors] = useState<FormErrors>({});
  const [promoCode, setPromoCode] = useState('');
  const [appliedPromo, setAppliedPromo] = useState<{ code: string; discountAmount: number; subtotal: number } | null>(null);
  const [promoNote, setPromoNote] = useState<string | null>(null);
  const [promoChecking, setPromoChecking] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('COD');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [receiptFileName, setReceiptFileName] = useState<string | null>(null);
  const [receiptPath, setReceiptPath] = useState<string | null>(null);
  const [receiptUploading, setReceiptUploading] = useState(false);
  const [receiptError, setReceiptError] = useState<string | null>(null);
  const [preorderAck, setPreorderAck] = useState(false);

  const deliveryFee = STORE_CONFIG.deliveryFee;
  const currentPromo = appliedPromo?.subtotal === totalPrice ? appliedPromo : null;
  const total = totalPrice + deliveryFee - (currentPromo?.discountAmount ?? 0);

  // Cross-reference cart items against loaded products to find which ones
  // are pre-orders, and their delivery timeframe. Cart items themselves
  // don't carry pre-order data — this keeps CartContext/cart storage
  // untouched.
  const preorderLines = items.reduce<{ item: (typeof items)[number]; message: string }[]>(
    (acc, item) => {
      const product = products.find((p) => p.id === item.productId);
      const version = product?.versions.find((v) =>
        v.sizes.some((s) => s.id === item.versionSizeId)
      );
      const message = version ? getPreorderMessage(version) : null;
      if (message) acc.push({ item, message });
      return acc;
    },
    []
  );
  const hasPreorderItems = preorderLines.length > 0;

  const handleChange = (field: keyof CheckoutForm, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
  };

  const validate = (): FormErrors => {
    const next: FormErrors = {};
    if (!form.fullName.trim()) next.fullName = 'Full name is required';
    if (!form.phone.trim()) {
      next.phone = 'Phone number is required';
    } else if (!PHONE_REGEX.test(form.phone.trim())) {
      next.phone = 'Enter a valid phone number';
    }
    if (form.mobilePhone.trim() && !PHONE_REGEX.test(form.mobilePhone.trim())) {
      next.mobilePhone = 'Enter a valid mobile number';
    }
    if (!form.email.trim()) {
      next.email = 'Email is required';
    } else if (!EMAIL_REGEX.test(form.email.trim())) {
      next.email = 'Enter a valid email address';
    }
    if (!form.addressLine1.trim()) next.addressLine1 = 'Address is required';
    if (!form.city.trim()) next.city = 'City is required';
    if (!form.district.trim()) next.district = 'District is required';
    return next;
  };

  const handleReceiptChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ''; // allow re-selecting the same file after an error
    if (!file) return;

    const extensionsByMime: Record<string, string> = {
      'image/jpeg': 'jpg',
      'image/png': 'png',
      'image/webp': 'webp',
    };
    const extension = extensionsByMime[file.type];
    if (!extension) {
      setReceiptError('Upload a JPG, PNG, or WebP image of your receipt.');
      return;
    }
    if (file.size > RECEIPT_MAX_BYTES) {
      setReceiptError('Receipt image must be under 5MB');
      return;
    }

    setReceiptError(null);
    setReceiptPath(null);
    setReceiptFileName(file.name);
    setReceiptUploading(true);

    try {
      const path = `${crypto.randomUUID()}.${extension}`;
      const { path: uploadedPath } = await uploadFile('payment-receipts', path, file, 'private');
      setReceiptPath(uploadedPath);
    } catch (err) {
      console.error('Receipt upload failed:', err);
      setReceiptError('Failed to upload receipt. Please try again.');
      setReceiptFileName(null);
    } finally {
      setReceiptUploading(false);
    }
  };

  const handleApplyPromo = async (e: FormEvent) => {
    e.preventDefault();
    if (!promoCode.trim()) return;
    setPromoChecking(true);
    setAppliedPromo(null);
    setPromoNote(null);
    const { data, error } = await supabase.rpc('preview_promo_code', {
      p_code: promoCode.trim().toUpperCase(),
      p_subtotal: totalPrice,
    });
    if (error) {
      setPromoNote('We could not check that code right now. Please try again.');
    } else if (typeof data === 'number' && data > 0) {
      const code = promoCode.trim().toUpperCase();
      setAppliedPromo({ code, discountAmount: data, subtotal: totalPrice });
      setPromoNote(`${code} applied: ${formatPrice(data)} off.`);
    } else {
      setPromoNote('That code is invalid, expired, or your order does not meet its minimum.');
    }
    setPromoChecking(false);
  };

  // Bank Transfer requires a successfully uploaded receipt before the order
  // can be placed at all — there's no "place now, upload later" path.
  const receiptRequired = paymentMethod === 'BANK_TRANSFER';
  const receiptBlocksSubmit = receiptRequired && (receiptUploading || !receiptPath);
  const preorderBlocksSubmit = hasPreorderItems && !preorderAck;

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const nextErrors = validate();
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) {
      requestAnimationFrame(() => {
        const field = checkoutFormRef.current?.querySelector<HTMLElement>('[aria-invalid="true"]');
        field?.focus();
        field?.scrollIntoView({ block: 'center', behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
      });
      return;
    }
    if (receiptBlocksSubmit) return;
    if (preorderBlocksSubmit) return;
    if (promoChecking) return;

    setSubmitError(null);
    setIsSubmitting(true);

    try {
      const { orderReference, total: authoritativeTotal } = await createOrder({
        fullName: form.fullName.trim(),
        phone: form.phone.trim(),
        mobilePhone: form.mobilePhone.trim(),
        email: form.email,
        addressLine1: form.addressLine1.trim(),
        addressLine2: form.addressLine2,
        city: form.city.trim(),
        district: form.district,
        postalCode: form.postalCode,
        subtotal: totalPrice,
        deliveryFee,
        total,
        items,
        paymentMethod,
        receiptPath: receiptPath ?? undefined,
        promoCode: currentPromo?.code,
      });

      clearCart();
      navigate('/order-success', {
        state: {
          orderReference,
          customerName: form.fullName,
          totalItems,
          total: authoritativeTotal,
          paymentMethod,
          // OrderSuccess.tsx should check this and render "Payment
          // Verification Required" instead of "Order Confirmed" for
          // Bank Transfer orders — see note in chat reply.
          requiresPaymentVerification: paymentMethod === 'BANK_TRANSFER',
        },
      });
    } catch {
      // Never render the thrown error's text — createOrder() logs the
      // technical details; customers only ever see this controlled message.
      setSubmitError(CHECKOUT_ERROR_MESSAGE);
      setIsSubmitting(false);
    }
  };

  if (items.length === 0) {
    return (
      <section className="relative flex min-h-screen flex-col items-center justify-center gap-4 overflow-hidden bg-background px-6 text-center">
        <div className="absolute inset-0 bg-web-pattern opacity-10" />
        <div className="relative z-10 flex flex-col items-center gap-4">
          <ShoppingBag aria-hidden="true" className="h-10 w-10 text-muted/30" />
          <h1 className="font-display text-3xl text-foreground">Your cart is empty</h1>
          <p className="text-muted">Add something before checking out.</p>
          <Link to="/shop" className="btn-primary">
            Browse Collection
          </Link>
        </div>
      </section>
    );
  }

  return (
    <section className="comic-page checkout-page relative min-h-screen bg-background py-24 lg:py-32">
      <div className="absolute inset-0 bg-web-pattern opacity-10" />

      <div className="relative z-10 mx-auto max-w-6xl px-4 sm:px-6">
        {/* Breadcrumb */}
        <nav className="mb-6 flex items-center gap-1.5 text-sm text-muted-foreground">
          <Link to="/" className="transition-colors hover:text-foreground">
            Home
          </Link>
          <span>/</span>
          <span className="text-muted">Checkout</span>
        </nav>

        <Link
          to="/shop"
          className="mb-6 inline-flex items-center gap-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" />
          Continue Shopping
        </Link>

        <h1 className="mb-8 font-display text-3xl text-foreground tracking-wide md:text-4xl">
          Checkout
        </h1>

        <form
          ref={checkoutFormRef}
          onSubmit={handleSubmit}
          className="grid grid-cols-1 gap-8 lg:grid-cols-[1fr_400px] lg:items-start"
        >
          {/* Mobile-only order overview. The full ORDER SUMMARY (with the
              submit button) stays at the bottom where it belongs; this just
              lets mobile customers see what they're buying and what it costs
              before working through the form, instead of after. Hidden from
              lg up, where the sticky summary column already does this. */}
          <motion.section
            aria-label="Order overview"
            className="glass rounded-2xl p-4 lg:hidden"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex items-center justify-between gap-3">
              <div className="flex min-w-0 items-center gap-3">
                <div className="flex flex-shrink-0 -space-x-2">
                  {items.slice(0, 3).map((item) => (
                    <div key={`${item.productId}-${item.size}`} className="h-11 w-11 overflow-hidden rounded-lg border border-border bg-background">
                      <img src={item.image} alt="" loading="lazy" className="h-full w-full object-cover" />
                    </div>
                  ))}
                </div>
                <p className="truncate text-sm font-medium text-foreground">
                  {totalItems} {totalItems === 1 ? 'item' : 'items'}{items.length > 3 && ` · +${items.length - 3} more`}
                </p>
              </div>
              <p className="shrink-0 font-display text-lg font-semibold text-foreground">{formatPrice(total)}</p>
            </div>
            <div className="mt-3 space-y-1 border-t border-border pt-3 text-xs text-muted-foreground">
              <div className="flex justify-between"><span>Subtotal</span><span>{formatPrice(totalPrice)}</span></div>
              <div className="flex justify-between"><span>Delivery</span><span>{formatPrice(deliveryFee)}</span></div>
              {currentPromo && <div className="flex justify-between text-green-700"><span>Promo</span><span>−{formatPrice(currentPromo.discountAmount)}</span></div>}
              <div className="flex justify-between font-semibold text-foreground"><span>Total</span><span>{formatPrice(total)}</span></div>
            </div>
          </motion.section>

          {/* Left: customer info, delivery, promo */}
          <motion.div
            className="checkout-details glass space-y-7 rounded-2xl p-4 sm:p-6 lg:p-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {/* Customer information */}
            <section className="checkout-customer-info" aria-labelledby="checkout-customer-heading">
              <div className="checkout-customer-heading">
                <span className="checkout-customer-number" aria-hidden="true">01</span>
                <div>
                  <p className="checkout-customer-kicker">Contact details</p>
                  <h2 id="checkout-customer-heading" className="font-display text-2xl text-foreground tracking-wide">
                    Customer information
                  </h2>
                  <p className="mt-1 text-sm text-muted-foreground">Where should we send your order?</p>
                </div>
              </div>
              <div className="grid grid-cols-1 gap-x-5 gap-y-4 sm:grid-cols-2">
                <FormField label="Full Name" required error={errors.fullName}>
                  <input
                    type="text"
                    value={form.fullName}
                    onChange={(e) => handleChange('fullName', e.target.value)}
                    className={inputClass(!!errors.fullName)}
                    placeholder="Peter Parker"
                    autoComplete="name"
                  />
                </FormField>

                <FormField label="Phone Number" required error={errors.phone}>
                  <input
                    type="tel"
                    value={form.phone}
                    onChange={(e) => handleChange('phone', e.target.value)}
                    className={inputClass(!!errors.phone)}
                    placeholder="07X XXX XXXX"
                    autoComplete="tel"
                  />
                </FormField>

                <FormField label="Mobile Number (Optional)" error={errors.mobilePhone}>
                  <input
                    type="tel"
                    value={form.mobilePhone}
                    onChange={(e) => handleChange('mobilePhone', e.target.value)}
                    className={inputClass(!!errors.mobilePhone)}
                    placeholder="07X XXX XXXX"
                    autoComplete="tel-national"
                  />
                </FormField>

                <div className="sm:col-span-2">
                  <FormField label="Email" required error={errors.email}>
                    <input
                      type="email"
                      required
                      value={form.email}
                      onChange={(e) => handleChange('email', e.target.value)}
                      className={inputClass(!!errors.email)}
                      placeholder="peter@dailybugle.com"
                      autoComplete="email"
                    />
                  </FormField>
                </div>

                <div className="sm:col-span-2">
                  <FormField label="Address Line 1" required error={errors.addressLine1}>
                    <input
                      type="text"
                      value={form.addressLine1}
                      onChange={(e) => handleChange('addressLine1', e.target.value)}
                      className={inputClass(!!errors.addressLine1)}
                      placeholder="House number, street"
                      autoComplete="address-line1"
                    />
                  </FormField>
                </div>

                <div className="sm:col-span-2">
                  <FormField label="Address Line 2">
                    <input
                      type="text"
                      value={form.addressLine2}
                      onChange={(e) => handleChange('addressLine2', e.target.value)}
                      className={inputClass(false)}
                      placeholder="Apartment, suite, unit (optional)"
                      autoComplete="address-line2"
                    />
                  </FormField>
                </div>

                <FormField label="City" required error={errors.city}>
                  <input
                    type="text"
                    value={form.city}
                    onChange={(e) => handleChange('city', e.target.value)}
                    className={inputClass(!!errors.city)}
                    placeholder="Colombo"
                    autoComplete="address-level2"
                  />
                </FormField>

                <FormField label="District" required error={errors.district}>
                  <select
                    value={form.district}
                    onChange={(e) => handleChange('district', e.target.value)}
                    className={inputClass(!!errors.district)}
                  >
                    <option value="" className="bg-background">
                      Select district
                    </option>
                    {DISTRICTS.map((d) => (
                      <option key={d} value={d} className="bg-background">
                        {d}
                      </option>
                    ))}
                  </select>
                </FormField>

                <FormField label="Postal Code">
                  <input
                    type="text"
                    value={form.postalCode}
                    onChange={(e) => handleChange('postalCode', e.target.value)}
                    className={inputClass(false)}
                    placeholder="10100"
                    autoComplete="postal-code"
                    inputMode="numeric"
                  />
                </FormField>
              </div>
            </section>

            {/* Delivery */}
            <div>
              <h2 className="mb-4 font-display text-xl text-foreground tracking-wide">Delivery</h2>
              <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-primary bg-primary/10 px-4 py-3">
                <div className="flex items-center gap-3">
                  <Truck className="h-5 w-5 flex-shrink-0 text-primary" />
                  <div>
                    <p className="text-sm font-medium text-foreground">
                      Standard Delivery (Islandwide)
                    </p>
                    <p className="text-xs text-muted-foreground">Arrives in 2-4 business days</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-primary">{formatPrice(deliveryFee)}</span>
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                </div>
              </div>
            </div>

            {/* Pre-order notice */}
            {hasPreorderItems && (
              <div>
                <h2 className="mb-4 font-display text-xl text-foreground tracking-wide">
                  Pre-order notice
                </h2>
                <div className="space-y-3 rounded-lg border border-primary/30 bg-primary/10 px-4 py-4">
                  <div className="flex items-start gap-3">
                    <Info className="mt-0.5 h-4 w-4 flex-shrink-0 text-primary" />
                    <p className="text-sm text-foreground">
                      {preorderLines.length === 1
                        ? 'Your order includes a pre-order item.'
                        : `Your order includes ${preorderLines.length} pre-order items.`}{' '}
                      These are fulfilled on a different timeline than in-stock items:
                    </p>
                  </div>
                  <ul className="ml-7 space-y-1 text-sm text-muted-foreground">
                    {preorderLines.map(({ item, message }) => (
                      <li key={`${item.productId}-${item.size}`}>
                        <span className="font-medium text-foreground">{item.name}</span>{' '}
                        ({item.size}) — {message}
                      </li>
                    ))}
                  </ul>
                  <label className="flex items-start gap-2 border-t border-primary/20 pt-3">
                    <input
                      type="checkbox"
                      checked={preorderAck}
                      onChange={(e) => setPreorderAck(e.target.checked)}
                      className="mt-0.5 h-4 w-4 flex-shrink-0 rounded border-border accent-primary"
                    />
                    <span className="text-sm text-foreground">
                      I understand that my pre-order item will be delivered within the stated
                      timeframe.
                    </span>
                  </label>
                </div>
              </div>
            )}

            {/* Payment method */}
            <div>
              <h2 className="mb-4 font-display text-xl text-foreground tracking-wide">
                Payment method
              </h2>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('COD')}
                  aria-pressed={paymentMethod === 'COD'}
                  className={paymentOptionClass(paymentMethod === 'COD')}
                >
                  <Wallet className="h-5 w-5 flex-shrink-0 text-primary" />
                  <div className="flex-1 text-left">
                    <p className="text-sm font-medium text-foreground">Cash on Delivery</p>
                    <p className="text-xs text-muted-foreground">Pay in cash when it arrives</p>
                  </div>
                  {paymentMethod === 'COD' && (
                    <CheckCircle2 className="h-4 w-4 flex-shrink-0 text-primary" />
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('BANK_TRANSFER')}
                  aria-pressed={paymentMethod === 'BANK_TRANSFER'}
                  className={paymentOptionClass(paymentMethod === 'BANK_TRANSFER')}
                >
                  <Landmark className="h-5 w-5 flex-shrink-0 text-primary" />
                  <div className="flex-1 text-left">
                    <p className="text-sm font-medium text-foreground">Bank Transfer</p>
                    <p className="text-xs text-muted-foreground">Transfer &amp; submit receipt</p>
                  </div>
                  {paymentMethod === 'BANK_TRANSFER' && (
                    <CheckCircle2 className="h-4 w-4 flex-shrink-0 text-primary" />
                  )}
                </button>
              </div>

              {paymentMethod === 'COD' && (
                <div className="mt-4 flex items-start gap-3 rounded-lg border border-border bg-surface px-4 py-3">
                  <Info className="mt-0.5 h-4 w-4 flex-shrink-0 text-primary" />
                  <p className="text-sm text-muted-foreground">Pay when your order arrives.</p>
                </div>
              )}

              {paymentMethod === 'BANK_TRANSFER' && (
                <div className="mt-4 space-y-4 rounded-lg border border-border bg-surface px-4 py-4">
                  <div className="flex items-start gap-3">
                    <Info className="mt-0.5 h-4 w-4 flex-shrink-0 text-primary" />
                    <p className="text-sm text-muted-foreground">
                      Complete your payment using bank transfer. After transferring the amount,
                      you will be able to submit your payment receipt in the next step.
                    </p>
                  </div>
                  <div className="grid grid-cols-1 gap-3 border-t border-border pt-4 text-sm sm:grid-cols-3">
                    <div>
                      <p className="text-xs text-muted-foreground">Bank Name</p>
                      <p className="font-medium text-foreground">Commercial bank - Dehiwala</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Account Name</p>
                      <p className="font-medium text-foreground">R A NEWZAN</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Account Number</p>
                      <p className="font-medium text-foreground">8015022901</p>
                    </div>
                  </div>

                  <div className="border-t border-border pt-4">
                    <label className="mb-2 block text-sm font-medium text-foreground">
                      Payment Receipt <span className="text-primary">*</span>
                    </label>
                    <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-dashed border-border bg-background px-4 py-3 text-sm text-muted-foreground transition-colors hover:border-primary/40">
                      <Upload className="h-4 w-4 flex-shrink-0" />
                      {receiptFileName ?? 'Choose receipt image (JPG, PNG — max 5MB)'}
                      <input
                        type="file"
                    accept="image/jpeg,image/png,image/webp"
                        onChange={handleReceiptChange}
                        className="sr-only"
                        aria-label="Upload payment receipt"
                      />
                    </label>

                    {receiptUploading && (
                      <p className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        Uploading receipt...
                      </p>
                    )}
                    {receiptError && (
                      <p className="mt-2 flex items-center gap-1.5 text-xs text-primary">
                        <AlertCircle className="h-3.5 w-3.5 flex-shrink-0" />
                        {receiptError}
                      </p>
                    )}
                    {receiptPath && !receiptUploading && (
                      <p className="mt-2 flex items-center gap-1.5 text-xs text-green-400">
                        <CheckCircle2 className="h-3.5 w-3.5 flex-shrink-0" />
                        Receipt uploaded — ready to submit
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Promo code */}
            <div>
              <h2 className="mb-4 font-display text-xl text-foreground tracking-wide">Promo code</h2>
              <div className="flex gap-2">
                <div className="relative min-w-0 flex-1">
                  <Tag className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted/30" />
                  <input
                    type="text"
                    value={promoCode}
                    onChange={(e) => {
                      setPromoCode(e.target.value.toUpperCase());
                      setAppliedPromo(null);
                      setPromoNote(null);
                    }}
                    className={`${inputClass(false)} pl-9`}
                    placeholder="Enter promo code"
                    aria-label="Promo code"
                  />
                </div>
                <button
                  type="button"
                  onClick={(e) => void handleApplyPromo(e)}
                  disabled={promoChecking || !promoCode.trim()}
                  className="btn-outline shrink-0 px-4 py-2.5 text-sm"
                >
                  {promoChecking ? 'Checking…' : currentPromo ? 'Applied' : 'Apply'}
                </button>
              </div>
              {(promoNote || (appliedPromo && !currentPromo)) && (
                <p role="status" className={`mt-2 text-xs ${currentPromo ? 'text-green-400' : 'text-muted-foreground'}`}>
                  {appliedPromo && !currentPromo ? 'Your cart changed. Apply the code again to update the discount.' : promoNote}
                </p>
              )}
            </div>
          </motion.div>

          {/* Right: order summary */}
          <motion.div
            className="checkout-summary glass space-y-6 rounded-2xl p-4 sm:p-6 lg:sticky lg:top-28 lg:p-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <h2 className="font-display text-xl text-foreground tracking-wide">Order summary</h2>

            <div className="space-y-4">
              {items.map((item) => {
                const product = products.find((p) => p.id === item.productId);
                const version = product?.versions.find((v) =>
                  v.sizes.some((s) => s.id === item.versionSizeId)
                );
                const preorderMessage = version ? getPreorderMessage(version) : null;
                return (
                <div key={`${item.productId}-${item.size}`} className="flex gap-3">
                  <div className="h-16 w-16 flex-shrink-0 overflow-hidden rounded-lg bg-background">
                    <img src={item.image} alt={item.name} loading="lazy" className="h-full w-full object-cover" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-foreground">{item.name}</p>
                    <p className="text-xs text-muted-foreground">
                      Size: {item.size} · Qty: {item.quantity}
                    </p>
                    {preorderMessage && (
                      <p className="mt-0.5 text-[11px] font-medium text-primary">
                        Pre-Order · {preorderMessage}
                      </p>
                    )}
                  </div>
                  <p className="shrink-0 self-center text-sm font-medium text-muted">
                    {formatPrice(item.price * item.quantity)}
                  </p>
                </div>
                );
              })}
            </div>

            <div className="space-y-2 border-t border-border pt-4 text-sm">
              <div className="flex items-center justify-between text-muted-foreground">
                <span>Subtotal ({totalItems} {totalItems === 1 ? 'item' : 'items'})</span>
                <span>{formatPrice(totalPrice)}</span>
              </div>
              <div className="flex items-center justify-between text-muted-foreground">
                <span>Delivery</span>
                <span>{formatPrice(deliveryFee)}</span>
              </div>
              {currentPromo && (
                <div className="flex items-center justify-between text-green-400">
                  <span>Promo ({currentPromo.code})</span>
                  <span>−{formatPrice(currentPromo.discountAmount)}</span>
                </div>
              )}
              <div className="flex items-center justify-between border-t border-border pt-2 font-display text-lg text-foreground">
                <span>Total</span>
                <span className="text-primary">{formatPrice(total)}</span>
              </div>
            </div>

            {submitError && (
              <p className="rounded-lg border border-primary/40 bg-primary/10 px-4 py-2.5 text-sm text-primary">
                {submitError}
              </p>
            )}

            <button
              type="submit"
              disabled={isSubmitting || receiptBlocksSubmit || preorderBlocksSubmit || promoChecking}
              className="btn-primary w-full"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Placing Order...
                </>
              ) : (
                'Place Order'
              )}
            </button>
            {receiptRequired && !receiptPath && !isSubmitting && (
              <p className="text-center text-xs text-muted-foreground">
                Upload your payment receipt above to place this order.
              </p>
            )}
            {preorderBlocksSubmit && !isSubmitting && (
              <p className="text-center text-xs text-muted-foreground">
                Please confirm the pre-order acknowledgement above to place this order.
              </p>
            )}
            {!receiptRequired && (
              <p className="text-center text-xs text-muted-foreground">
                No payment is collected now — we'll contact you to confirm delivery.
              </p>
            )}
            <p className="text-center text-xs text-muted-foreground">
              By placing your order, you agree to our{' '}
              <Link to="/return-policy" className="text-primary transition-colors hover:underline">
                Return &amp; Exchange Policy
              </Link>
              .
            </p>
          </motion.div>
        </form>
      </div>
    </section>
  );
}

function paymentOptionClass(active: boolean) {
  return `flex items-center gap-3 rounded-lg border px-4 py-3 text-left transition-colors ${
    active
      ? 'border-primary bg-primary/20'
      : 'border-border bg-surface hover:border-primary/40'
  }`;
}

function inputClass(hasError: boolean) {
  return `w-full rounded-lg border bg-surface px-4 py-2.5 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus:border-primary ${
    hasError ? 'border-primary/60' : 'border-border'
  }`;
}

function FormField({
  label,
  required,
  error,
  children,
}: {
  label: string;
  required?: boolean;
  error?: string;
  children: ReactNode;
}) {
  const id = useId();
  const errorId = `${id}-error`;
  const control = isValidElement(children)
    ? cloneElement(children as ReactElement<{
        id?: string;
        'aria-invalid'?: boolean;
        'aria-required'?: boolean;
        'aria-describedby'?: string;
      }>, {
        id,
        'aria-invalid': Boolean(error),
        'aria-required': required || undefined,
        'aria-describedby': error ? errorId : undefined,
      })
    : children;

  return (
    <div>
      <label htmlFor={id} className="checkout-field-label mb-1.5 block text-sm font-medium text-muted-foreground">
        {label} {required && <span className="text-primary">*</span>}
      </label>
      {control}
      {error && <p id={errorId} className="mt-1 text-xs font-semibold text-primary">{error}</p>}
    </div>
  );
}
