import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Instagram, MessageCircle, Heart } from 'lucide-react';

const infoLinks = [
  { label: 'About', to: '/about' },
  { label: 'FAQ', to: '/faq' },
  { label: 'Contact', to: '/contact' },
  { label: 'Track Order', to: '/track-order' },
  { label: 'Return & Exchange Policy', to: '/return-policy' },
  { label: 'Terms & Conditions', to: '/terms-and-conditions' },
];

export default function Footer() {
  return (
    <footer className="store-footer comic-page relative border-t-4 border-foreground bg-background">
      {/* Animated top line */}
      <motion.div
        className="absolute top-0 left-0 h-1 bg-warning"
        initial={{ width: 0 }}
        whileInView={{ width: '100%' }}
        viewport={{ once: true }}
        transition={{ duration: 1.5, ease: 'easeOut' }}
      />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-12">
        <div className="flex flex-col items-center justify-between gap-8 md:flex-row">
          {/* Logo */}
          <motion.div className="flex items-center gap-2" whileHover={{ scale: 1.02 }}>
            <div className="relative flex h-9 w-9 items-center justify-center">
              <div className="absolute inset-0 blur-md opacity-50" />
              <img
                src="/images/logo/logo-black.svg"
                alt="ComicCulture"
                className="relative h-10 w-10"
              />
            </div>
            <div className="flex flex-col">
              <span className="font-display text-base leading-none text-foreground">Comic</span>
              <span className="font-display text-base leading-none text-primary">Culture</span>
            </div>
          </motion.div>

          {/* Social links */}
          <div className="flex items-center gap-6">
            <motion.a
              href="https://instagram.com/comicculture.lk"
              target="_blank"
              rel="noopener noreferrer"
              className="flex min-h-11 items-center gap-2 text-muted transition-colors hover:text-foreground"
              whileHover={{ y: -2 }}
            >
              <Instagram className="h-5 w-5" />
              <span className="text-sm font-medium">Instagram</span>
            </motion.a>
            <motion.a
              href="https://wa.me/94787756338"
              target="_blank"
              rel="noopener noreferrer"
              className="flex min-h-11 items-center gap-2 text-muted transition-colors hover:text-foreground"
              whileHover={{ y: -2 }}
            >
              <MessageCircle className="h-5 w-5" />
              <span className="text-sm font-medium">WhatsApp</span>
            </motion.a>
          </div>
        </div>

        {/* Informational nav */}
        <nav aria-label="Customer support" className="mt-8 grid grid-cols-2 gap-x-4 gap-y-1 border-t border-border pt-6 md:mt-10 md:flex md:flex-wrap md:items-center md:justify-center md:gap-x-6 md:gap-y-2 md:pt-8">
          {infoLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className="flex min-h-11 items-center text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Bottom */}
        <div className="mt-8 border-t border-border pt-8 text-center">
          <p className="flex items-center justify-center gap-1 text-sm text-muted">
            Made with <Heart className="h-4 w-4 text-primary" /> in Sri Lanka
          </p>
          <p className="mt-2 text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} ComicCulture. All rights reserved.
          </p>
          <p className="mt-2 text-xs text-muted-foreground">
            Fan-inspired designs. Not affiliated with Marvel, Sony, or DC.
          </p>
        </div>
      </div>
    </footer>
  );
}
