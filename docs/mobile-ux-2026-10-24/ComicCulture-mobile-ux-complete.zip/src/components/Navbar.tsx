import { useState, useEffect, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, ShoppingBag, ShoppingCart, Search, PackageSearch } from 'lucide-react';
import { useCart } from '../hooks/useCart';
import SearchOverlay from './SearchOverlay';
import { useDialog } from '../hooks/useDialog';

const MotionLink = motion.create(Link);

// Keep the main nav focused on shopping and expose order support as a utility action.
const navLinks = [
  { label: 'Shop', to: '/shop' },
  { label: 'Collections', to: '/#collections' },
  { label: 'New Arrivals', to: '/#new-arrivals' },
];

const secondaryLinks = [
  { label: 'About', to: '/about' },
  { label: 'FAQ', to: '/faq' },
  { label: 'Contact', to: '/contact' },
  { label: 'Track Order', to: '/track-order' },
  { label: 'Return Policy', to: '/return-policy' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const { totalItems, openCart } = useCart();
  const location = useLocation();
  const menuRef = useRef<HTMLElement>(null);
  useDialog(mobileOpen, menuRef, () => setMobileOpen(false));
  useEffect(() => { setMobileOpen(false); setSearchOpen(false); }, [location.pathname, location.hash]);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleOpenSearch = () => {
    setMobileOpen(false);
    setSearchOpen(true);
  };

  return (
    <>
      <motion.header
        className={`store-header fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled ? 'glass py-3' : 'border-b border-border bg-background/95 py-4 shadow-sm backdrop-blur-xl'
        }`}
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        {/* Below lg the outer columns size to their content so the centre nav
            gets the leftover width (equal thirds would crowd the links into
            two lines at ~768px). From lg the original equal-thirds grid takes
            over, keeping the desktop layout exactly as before. */}
        <nav className="mx-auto grid max-w-7xl grid-cols-[auto_1fr_auto] items-center px-4 sm:px-6 lg:grid-cols-3">
          {/* Left: Logo — serves as the Home link */}
          <div className="flex items-center justify-start">
            <MotionLink
              to="/"
              className="flex items-center gap-2"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="relative flex h-9 w-9 items-center justify-center">
                <div className="absolute inset-0 opacity-50" />
                <img
                  src="/images/logo/logo-black.svg"
                  alt="ComicCulture"
                  className="relative h-8 w-8"
                />
              </div>
              <div className="flex flex-col">
                <span className="font-display text-base text-foreground leading-none">Comic</span>
                <span className="font-display text-base text-primary leading-none">Culture</span>
              </div>
            </MotionLink>
          </div>

          {/* Center: Desktop Nav Links */}
          <ul className="hidden items-center justify-center gap-6 md:flex lg:gap-8">
            {navLinks.map((link) => (
              <li key={link.to}>
                <Link
                  to={link.to}
                  className="group relative py-2 text-sm font-medium text-foreground transition-colors hover:text-primary"
                >
                  {link.label}
                  <span className="absolute -bottom-0.5 left-0 h-px w-0 bg-primary transition-all group-hover:w-full" />
                </Link>
              </li>
            ))}
          </ul>

          {/* Right: Actions */}
          <div className="flex items-center justify-end">
            {/* CTA Buttons (desktop) */}
            <div className="hidden md:flex items-center gap-4">
              <button
                onClick={handleOpenSearch}
                className="relative rounded-lg p-2 text-muted transition-colors hover:text-foreground"
                aria-label="Open search"
              >
                <Search className="h-5 w-5" />
              </button>
              <button
                onClick={() => { setMobileOpen(false); openCart(); }}
                className="relative rounded-lg p-2 text-muted transition-colors hover:text-foreground"
                aria-label="Open cart"
              >
                <ShoppingCart className="h-5 w-5" />
                {totalItems > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                    {totalItems}
                  </span>
                )}
              </button>
              <Link to="/track-order" className="inline-flex min-h-10 items-center gap-2 rounded-lg px-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
                <PackageSearch className="h-4 w-4" />
                Track order
              </Link>
            </div>

            {/* Mobile: Search + Cart + Menu Toggle */}
            <div className="flex items-center gap-1 md:hidden">
              <button
                onClick={handleOpenSearch}
                className="relative p-2 text-foreground"
                aria-label="Open search"
              >
                <Search className="h-5 w-5" />
              </button>
              <button
                onClick={() => { setMobileOpen(false); openCart(); }}
                className="relative p-2 text-foreground"
                aria-label="Open cart"
              >
                <ShoppingCart className="h-5 w-5" />
                {totalItems > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                    {totalItems}
                  </span>
                )}
              </button>
              <motion.button
                className="p-2 text-foreground"
                onClick={() => setMobileOpen(!mobileOpen)}
                whileTap={{ scale: 0.9 }}
                aria-label="Toggle menu"
                aria-expanded={mobileOpen}
                aria-controls="mobile-navigation"
              >
                {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </motion.button>
            </div>
          </div>
        </nav>
      </motion.header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            className="fixed inset-0 z-[60] md:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {/* Backdrop */}
            <motion.div
              className="absolute inset-0 bg-background/80 backdrop-blur-xl"
              onClick={() => setMobileOpen(false)}
            />

            {/* Menu Content */}
            <motion.nav
              ref={menuRef}
              id="mobile-navigation"
              role="dialog"
              aria-modal="true"
              aria-label="Navigation"
              tabIndex={-1}
              className="mobile-navigation absolute inset-y-0 right-0 flex w-full max-w-sm flex-col overflow-y-auto bg-surface px-5 py-5 shadow-lg"
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -20, opacity: 0 }}
            >
              <div className="mb-5 flex items-center justify-between border-b border-border pb-4">
                <span className="font-display text-2xl">Explore ComicCulture</span>
                <button type="button" onClick={() => setMobileOpen(false)} className="icon-button" aria-label="Close menu"><X className="h-5 w-5" /></button>
              </div>
              <ul className="flex flex-col gap-1">
                {navLinks.map((link) => (
                  <li key={link.to}>
                    <Link
                      to={link.to}
                      className="block rounded-lg px-4 py-3 text-lg font-medium text-muted transition-colors hover:bg-surface-hover hover:text-foreground"
                      onClick={() => setMobileOpen(false)}
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>

              <div className="mt-6 pt-6 border-t border-border">
                <Link
                  to="/shop"
                  className="btn-primary w-full justify-center"
                  onClick={() => setMobileOpen(false)}
                >
                  <ShoppingBag className="h-5 w-5" />
                  Shop Now
                </Link>
              </div>

              {/* Secondary / informational links */}
              <div className="mt-6 pt-6 border-t border-border">
                <ul className="flex flex-col gap-1">
                  {secondaryLinks.map((link) => (
                    <li key={link.to}>
                      <Link
                        to={link.to}
                        className="block rounded-lg px-4 py-3 text-sm font-medium text-muted-foreground transition-colors hover:bg-surface-hover hover:text-foreground"
                        onClick={() => setMobileOpen(false)}
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </motion.nav>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Search Overlay */}
      <AnimatePresence>
        {searchOpen && <SearchOverlay onClose={() => setSearchOpen(false)} />}
      </AnimatePresence>
    </>
  );
}
